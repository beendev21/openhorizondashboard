import { Header } from "@/components/Header";
import { ModelagemMatematica } from "@/components/ModelagemMatematica";
import { SimuladorInterativo } from "@/components/SimuladorInterativo";
import { GraficosProjecao } from "@/components/GraficosProjecao";
import { HardwareRequirements } from "@/components/HardwareRequirements";
import { Sustentabilidade } from "@/components/Sustentabilidade";
import { useState } from "react";

export interface SimulatorParams {
  baseUsers: number;
  growthRate: number;
  arpu: number;
  timePeriod: number;
}

const Index = () => {
  const [simulatorParams, setSimulatorParams] = useState<SimulatorParams>({
    baseUsers: 100,
    growthRate: 15,
    arpu: 10,
    timePeriod: 12,
  });

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main id="main-content" className="max-w-7xl mx-auto px-4 py-8 md:py-12" role="main">
        <div className="mb-8 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Dashboard de Projeção Exponencial
          </h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Sistema completo de análise e projeção de crescimento com foco em sustentabilidade e eficiência
          </p>
        </div>

        <ModelagemMatematica />
        <HardwareRequirements />
        <SimuladorInterativo 
          params={simulatorParams}
          onParamsChange={setSimulatorParams}
        />
        <GraficosProjecao params={simulatorParams} />
        <Sustentabilidade />
      </main>

      <footer className="bg-card border-t border-border py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-muted-foreground">
            OpenHorizon - Projeto desenvolvido para análise de crescimento exponencial
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            © 2025 Happy Game Team - Todos os direitos reservados
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
