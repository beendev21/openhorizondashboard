import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Line, Bar, Doughnut } from "react-chartjs-2";
import { useState, useMemo } from "react";
import { SimulatorParams } from "@/pages/Index";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface GraficosProjecaoProps {
  params: SimulatorParams;
}

export const GraficosProjecao = ({ params }: GraficosProjecaoProps) => {
  const [activeChart, setActiveChart] = useState<'users' | 'revenue' | 'costs'>('users');
  const { baseUsers, growthRate, arpu, timePeriod } = params;

  // Gera array de labels baseado no período selecionado
  const monthLabels = useMemo(() => {
    const labels = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    const result = [];
    for (let i = 0; i < timePeriod; i++) {
      result.push(labels[i % 12]);
    }
    return result;
  }, [timePeriod]);
  
  // Calcula dados de usuários baseado nos parâmetros do simulador
  const usersData = useMemo(() => {
    return monthLabels.map((_, i) => 
      Math.round(baseUsers * Math.pow(1 + growthRate / 100, i))
    );
  }, [monthLabels, baseUsers, growthRate]);

  // Calcula dados de receita baseado nos usuários e ARPU
  const revenueData = useMemo(() => {
    return usersData.map(users => users * arpu);
  }, [usersData, arpu]);

  // Dados de custos (simplificado)
  const costsData = useMemo(() => {
    return monthLabels.map((_, i) => 800 + (i * 20));
  }, [monthLabels]);

  // Opções de gráfico otimizadas para WCAG (acessibilidade)
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: true,
        position: 'top' as const,
        labels: {
          color: 'hsl(var(--foreground))',
          font: { 
            size: 16,
            weight: 'bold' as const
          },
          padding: 16,
          usePointStyle: true,
          pointStyle: 'circle' as const
        }
      },
      tooltip: {
        backgroundColor: 'hsl(var(--card))',
        titleColor: 'hsl(var(--foreground))',
        bodyColor: 'hsl(var(--foreground))',
        borderColor: 'hsl(var(--primary))',
        borderWidth: 2,
        padding: 12,
        titleFont: {
          size: 16,
          weight: 'bold' as const
        },
        bodyFont: {
          size: 14
        },
        displayColors: true,
        boxWidth: 20,
        boxHeight: 20
      }
    },
    scales: {
      y: {
        ticks: { 
          color: 'hsl(var(--foreground))',
          font: { size: 14, weight: 'bold' as const }
        },
        grid: { 
          color: 'hsl(var(--border))',
          lineWidth: 1
        },
        border: {
          color: 'hsl(var(--foreground))',
          width: 2
        }
      },
      x: {
        ticks: { 
          color: 'hsl(var(--foreground))',
          font: { size: 14, weight: 'bold' as const }
        },
        grid: { 
          color: 'hsl(var(--border))',
          lineWidth: 1
        },
        border: {
          color: 'hsl(var(--foreground))',
          width: 2
        }
      }
    }
  };

  // Dados do gráfico de usuários com melhor contraste (WCAG AA)
  const usersChartData = useMemo(() => ({
    labels: monthLabels,
    datasets: [{
      label: 'Usuários Projetados',
      data: usersData,
      borderColor: 'rgb(102, 126, 234)', // Alto contraste
      backgroundColor: 'rgba(102, 126, 234, 0.2)',
      fill: true,
      tension: 0.4,
      borderWidth: 3,
      pointRadius: 6,
      pointHoverRadius: 8,
      pointBackgroundColor: 'rgb(102, 126, 234)',
      pointBorderColor: '#fff',
      pointBorderWidth: 2,
      pointHoverBackgroundColor: '#fff',
      pointHoverBorderColor: 'rgb(102, 126, 234)',
      pointHoverBorderWidth: 3
    }]
  }), [monthLabels, usersData]);

  // Dados do gráfico de receita com cores de alto contraste
  const revenueChartData = useMemo(() => ({
    labels: monthLabels,
    datasets: [{
      label: 'Receita Total (R$)',
      data: revenueData,
      backgroundColor: 'rgb(16, 185, 129)', // Verde com alto contraste
      borderColor: 'rgb(5, 150, 105)',
      borderWidth: 3,
      hoverBackgroundColor: 'rgb(5, 150, 105)',
      hoverBorderColor: 'rgb(4, 120, 87)',
      hoverBorderWidth: 4
    }]
  }), [monthLabels, revenueData]);

  // Gráfico de pizza com cores de alto contraste e bordas visíveis (WCAG AAA)
  const costsChartData = useMemo(() => ({
    labels: ['Servidores', 'Licenças', 'Marketing', 'Suporte', 'Outros'],
    datasets: [{
      label: 'Custos Mensais (R$)',
      data: [350, 250, 150, 50, 200],
      backgroundColor: [
        'rgb(102, 126, 234)', // Azul vibrante
        'rgb(16, 185, 129)',  // Verde vibrante
        'rgb(251, 191, 36)',  // Amarelo vibrante
        'rgb(59, 130, 246)',  // Azul claro
        'rgb(239, 68, 68)'    // Vermelho vibrante
      ],
      borderWidth: 4,
      borderColor: '#fff',
      hoverBorderWidth: 6,
      hoverBorderColor: '#000',
      hoverOffset: 15
    }]
  }), []);

  return (
    <section id="graficos" className="mb-12" aria-labelledby="graficos-heading">
      <Card className="card-hover bg-card border-2 border-border">
        <CardHeader className="pb-4">
          <CardTitle id="graficos-heading" className="text-3xl font-bold">
            Visualização de Dados
          </CardTitle>
          <CardDescription className="text-base mt-2">
            Acompanhe as projeções através de gráficos interativos com alto contraste
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3 mb-8" role="tablist" aria-label="Seleção de gráficos">
            <Button
              variant={activeChart === 'users' ? 'default' : 'outline'}
              onClick={() => setActiveChart('users')}
              aria-pressed={activeChart === 'users'}
              role="tab"
              aria-selected={activeChart === 'users'}
              aria-controls="chart-panel"
              className="text-base font-semibold min-h-[48px] px-6"
            >
              📊 Crescimento de Usuários
            </Button>
            <Button
              variant={activeChart === 'revenue' ? 'default' : 'outline'}
              onClick={() => setActiveChart('revenue')}
              aria-pressed={activeChart === 'revenue'}
              role="tab"
              aria-selected={activeChart === 'revenue'}
              aria-controls="chart-panel"
              className="text-base font-semibold min-h-[48px] px-6"
            >
              💰 Projeção de Receita
            </Button>
            <Button
              variant={activeChart === 'costs' ? 'default' : 'outline'}
              onClick={() => setActiveChart('costs')}
              aria-pressed={activeChart === 'costs'}
              role="tab"
              aria-selected={activeChart === 'costs'}
              aria-controls="chart-panel"
              className="text-base font-semibold min-h-[48px] px-6"
            >
              📈 Distribuição de Custos
            </Button>
          </div>

          {/* Descrição textual do gráfico para leitores de tela */}
          <div className="sr-only" aria-live="polite">
            {activeChart === 'users' && `Visualizando gráfico de linha com projeção de ${usersData[usersData.length - 1]} usuários no mês ${timePeriod}`}
            {activeChart === 'revenue' && `Visualizando gráfico de barras com receita projetada de R$ ${revenueData[revenueData.length - 1].toLocaleString('pt-BR')}`}
            {activeChart === 'costs' && 'Visualizando gráfico de pizza com distribuição de custos mensais'}
          </div>

          <div 
            id="chart-panel"
            className="h-[500px] bg-background/50 p-6 rounded-lg border-2 border-border" 
            role="tabpanel"
            aria-label={`Gráfico de ${activeChart === 'users' ? 'crescimento de usuários' : activeChart === 'revenue' ? 'projeção de receita' : 'distribuição de custos'}`}
          >
            {activeChart === 'users' && <Line data={usersChartData} options={chartOptions} />}
            {activeChart === 'revenue' && <Bar data={revenueChartData} options={chartOptions} />}
            {activeChart === 'costs' && <Doughnut data={costsChartData} options={{ ...chartOptions, scales: undefined }} />}
          </div>

          {/* Resumo textual dos dados para melhor acessibilidade */}
          <div className="mt-6 p-4 bg-muted/50 rounded-lg border border-border">
            <h4 className="font-bold text-lg mb-3">Resumo dos Dados:</h4>
            {activeChart === 'users' && (
              <div className="space-y-2">
                <p className="text-base">
                  <span className="font-semibold">Usuários Iniciais:</span> {baseUsers.toLocaleString('pt-BR')}
                </p>
                <p className="text-base">
                  <span className="font-semibold">Taxa de Crescimento:</span> {growthRate}% ao mês
                </p>
                <p className="text-base">
                  <span className="font-semibold">Projeção para {timePeriod} meses:</span> {usersData[usersData.length - 1].toLocaleString('pt-BR')} usuários
                </p>
                <p className="text-base">
                  <span className="font-semibold">Crescimento Total:</span> {Math.round((usersData[usersData.length - 1] / baseUsers - 1) * 100)}%
                </p>
              </div>
            )}
            {activeChart === 'revenue' && (
              <div className="space-y-2">
                <p className="text-base">
                  <span className="font-semibold">Receita por Usuário (ARPU):</span> R$ {arpu.toLocaleString('pt-BR')}
                </p>
                <p className="text-base">
                  <span className="font-semibold">Usuários Projetados:</span> {usersData[usersData.length - 1].toLocaleString('pt-BR')}
                </p>
                <p className="text-base">
                  <span className="font-semibold">Receita Total Projetada:</span> R$ {revenueData[revenueData.length - 1].toLocaleString('pt-BR')}
                </p>
                <p className="text-base">
                  <span className="font-semibold">Período:</span> {timePeriod} meses
                </p>
              </div>
            )}
            {activeChart === 'costs' && (
              <div className="space-y-2">
                <p className="text-base">
                  <span className="font-semibold">Servidores:</span> R$ 350,00 (35%)
                </p>
                <p className="text-base">
                  <span className="font-semibold">Licenças:</span> R$ 250,00 (25%)
                </p>
                <p className="text-base">
                  <span className="font-semibold">Marketing:</span> R$ 150,00 (15%)
                </p>
                <p className="text-base">
                  <span className="font-semibold">Suporte:</span> R$ 50,00 (5%)
                </p>
                <p className="text-base">
                  <span className="font-semibold">Outros:</span> R$ 200,00 (20%)
                </p>
                <p className="text-base font-bold mt-3">
                  <span className="font-semibold">Total Mensal:</span> R$ 1.000,00
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
