import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Cpu, HardDrive, MemoryStick, Monitor, Leaf } from "lucide-react";

export const HardwareRequirements = () => {
  return (
    <section className="mb-12" aria-labelledby="hardware-heading">
      <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
        <CardHeader>
          <CardTitle id="hardware-heading" className="text-3xl flex items-center gap-3">
            <Cpu className="h-8 w-8 text-primary" />
            Requisitos de Hardware
          </CardTitle>
          <CardDescription className="text-base">
            Configurações recomendadas para execução otimizada do sistema
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[200px]">Componente</TableHead>
                  <TableHead>Mínimo (Funcional)</TableHead>
                  <TableHead>Recomendado (Ideal)</TableHead>
                  <TableHead>Impacto</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium flex items-center gap-2">
                    <Cpu className="h-5 w-5 text-primary" />
                    CPU
                  </TableCell>
                  <TableCell>Intel Core i3 / Ryzen 3<br/><span className="text-xs text-muted-foreground">2 núcleos, 4 threads</span></TableCell>
                  <TableCell>Intel Core i5+ / Ryzen 5+<br/><span className="text-xs text-muted-foreground">4+ núcleos, 8+ threads</span></TableCell>
                  <TableCell className="text-sm text-muted-foreground">Processamento de dados e cálculos matemáticos complexos</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium flex items-center gap-2">
                    <MemoryStick className="h-5 w-5 text-success" />
                    RAM
                  </TableCell>
                  <TableCell>4GB DDR4<br/><span className="text-xs text-muted-foreground">2400MHz</span></TableCell>
                  <TableCell>8GB+ DDR5<br/><span className="text-xs text-muted-foreground">4800MHz+</span></TableCell>
                  <TableCell className="text-sm text-muted-foreground">Multitarefa e cache de dados. DDR5 oferece 20% mais eficiência energética</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium flex items-center gap-2">
                    <HardDrive className="h-5 w-5 text-info" />
                    Armazenamento
                  </TableCell>
                  <TableCell>HDD 500GB<br/><span className="text-xs text-muted-foreground">5400 RPM</span></TableCell>
                  <TableCell>SSD NVMe 256GB+<br/><span className="text-xs text-muted-foreground">PCIe Gen 3/4</span></TableCell>
                  <TableCell className="text-sm text-muted-foreground">SSD: 10x mais rápido, -70% consumo energético, maior durabilidade</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium flex items-center gap-2">
                    <Monitor className="h-5 w-5 text-warning" />
                    GPU
                  </TableCell>
                  <TableCell>Integrada<br/><span className="text-xs text-muted-foreground">Intel UHD / Vega</span></TableCell>
                  <TableCell>Dedicada (opcional)<br/><span className="text-xs text-muted-foreground">GTX 1650+ / RX 5500+</span></TableCell>
                  <TableCell className="text-sm text-muted-foreground">Renderização de gráficos e visualizações complexas (opcional)</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          <div className="mt-6 grid md:grid-cols-2 gap-4">
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Comparativo: HD vs SSD</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Velocidade de Leitura:</span>
                  <span className="font-semibold">SSD: 3500 MB/s vs HD: 120 MB/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Tempo de Boot:</span>
                  <span className="font-semibold">SSD: 10s vs HD: 45s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Consumo Energético:</span>
                  <span className="font-semibold">SSD: 2-3W vs HD: 6-7W</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Durabilidade:</span>
                  <span className="font-semibold">SSD: Sem partes móveis</span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-success/5 border-success/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Comparativo: DDR4 vs DDR5</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Velocidade:</span>
                  <span className="font-semibold">DDR5: 4800+ MHz vs DDR4: 3200 MHz</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Voltagem:</span>
                  <span className="font-semibold">DDR5: 1.1V vs DDR4: 1.2V</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Eficiência:</span>
                  <span className="font-semibold">DDR5: +20% eficiência energética</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Capacidade:</span>
                  <span className="font-semibold">DDR5: Até 64GB/módulo</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="mt-6 p-4 bg-muted/50 rounded-lg">
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Leaf className="h-5 w-5 text-success" />
              Impacto na Sustentabilidade
            </h4>
            <p className="text-sm text-muted-foreground">
              A escolha de hardware eficiente (SSD, DDR5, CPUs modernos) não só melhora o desempenho, 
              mas reduz significativamente o consumo energético e a pegada de carbono do sistema. 
              Um setup recomendado pode economizar até <span className="font-bold text-success">150 kWh/ano</span> comparado 
              às configurações mais antigas.
            </p>
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
