import { Moon, Sun, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState, useEffect } from "react";

export const Header = () => {
  const [theme, setTheme] = useState<"light" | "dark">("dark");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove("light", "dark");
    root.classList.add(theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark");
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="gradient-primary text-primary-foreground py-8 px-4 shadow-2xl sticky top-0 z-50 backdrop-blur-lg bg-opacity-95" role="banner">
      <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:top-2 focus:left-2 focus:z-50 focus:bg-primary focus:text-primary-foreground focus:px-4 focus:py-2 focus:rounded-lg">
        Pular para o conteúdo principal
      </a>
      
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold tracking-tight">OpenHorizon</h1>
              <p className="text-sm md:text-base opacity-90 mt-1">Projeções dinâmicas para crescimento e receita</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden text-primary-foreground hover:bg-primary-foreground/10"
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>

            <nav className={`${mobileMenuOpen ? "flex" : "hidden"} md:flex absolute md:relative top-full left-0 right-0 md:top-auto bg-card md:bg-transparent p-4 md:p-0 flex-col md:flex-row gap-4 rounded-b-lg md:rounded-none shadow-lg md:shadow-none`} role="navigation" aria-label="Menu principal">
              <Button
                variant="ghost"
                onClick={() => scrollToSection("modelagem")}
                className="text-primary-foreground hover:bg-primary-foreground/10 justify-start md:justify-center"
              >
                Modelagem
              </Button>
              <Button
                variant="ghost"
                onClick={() => scrollToSection("simulador")}
                className="text-primary-foreground hover:bg-primary-foreground/10 justify-start md:justify-center"
              >
                Simulador
              </Button>
              <Button
                variant="ghost"
                onClick={() => scrollToSection("graficos")}
                className="text-primary-foreground hover:bg-primary-foreground/10 justify-start md:justify-center"
              >
                Gráficos
              </Button>
              <Button
                variant="ghost"
                onClick={() => scrollToSection("sustentabilidade")}
                className="text-primary-foreground hover:bg-primary-foreground/10 justify-start md:justify-center"
              >
                Sustentabilidade
              </Button>
            </nav>

            <Button
              variant="outline"
              size="icon"
              onClick={toggleTheme}
              className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10"
              aria-label={theme === "dark" ? "Ativar modo claro" : "Ativar modo escuro"}
              aria-pressed={theme === "dark"}
            >
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
};
