import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, Users, DollarSign } from "lucide-react";

export const ModelagemMatematica = () => {
  return (
    <section id="modelagem" className="mb-12" aria-labelledby="modelagem-heading">
      <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
        <CardHeader>
          <CardTitle id="modelagem-heading" className="text-3xl flex items-center gap-3">
            <TrendingUp className="h-8 w-8 text-primary" />
            Modelagem Matemática Aplicada
          </CardTitle>
          <CardDescription className="text-base">
            Compreenda a matemática por trás do crescimento exponencial
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <p className="text-muted-foreground text-lg">
                Para modelar o crescimento exponencial no projeto, utilizamos a fórmula de juros compostos, adaptada para projeções de negócios:
              </p>
              
              <div className="bg-primary/10 p-6 rounded-lg border border-primary/20">
                <p className="font-mono text-2xl md:text-3xl mb-3 text-primary font-bold text-center">
                  N(t) = N₀ × (1 + r)<sup>t</sup>
                </p>
                <p className="text-sm text-muted-foreground text-center">
                  Modelo de crescimento discreto ao longo do tempo
                </p>
              </div>

              <div className="space-y-3">
                <p className="font-semibold text-foreground">Legenda:</p>
                <ul className="space-y-2">
                  <li className="flex items-start gap-2">
                    <span className="font-semibold text-primary min-w-[60px]">N(t):</span>
                    <span className="text-muted-foreground">Valor projetado no tempo t</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-semibold text-primary min-w-[60px]">N₀:</span>
                    <span className="text-muted-foreground">Valor inicial (ex: 100 usuários)</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-semibold text-primary min-w-[60px]">r:</span>
                    <span className="text-muted-foreground">Taxa de crescimento por período</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="font-semibold text-primary min-w-[60px]">t:</span>
                    <span className="text-muted-foreground">Tempo decorrido em períodos</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="space-y-4">
              <p className="text-lg font-medium mb-4">Aplicação Prática:</p>
              
              <Card className="bg-primary/5 border-primary/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    Projeção de Usuários
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg">
                    100 × (1.15)<sup>12</sup> = <span className="font-bold text-primary text-2xl">535 usuários</span>
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">em 12 meses</p>
                </CardContent>
              </Card>

              <Card className="bg-success/5 border-success/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-success" />
                    Crescimento de Custos
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg">
                    De R$800 para <span className="font-bold text-success text-2xl">R$1.243</span>
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">custos mensais em 12 meses</p>
                </CardContent>
              </Card>

              <Card className="bg-warning/5 border-warning/20">
                <CardHeader className="pb-3">
                  <CardTitle className="text-xl flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-warning" />
                    ROI Esperado
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-lg">
                    Payback em <span className="font-bold text-warning text-2xl">~8 meses</span>
                  </p>
                  <p className="text-sm text-muted-foreground mt-2">Investimento inicial: R$16.300</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </CardContent>
      </Card>
    </section>
  );
};
