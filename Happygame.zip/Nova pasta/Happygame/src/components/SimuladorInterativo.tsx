import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Users, DollarSign, TrendingUp } from "lucide-react";
import { useEffect, useMemo } from "react";
import { SimulatorParams } from "@/pages/Index";

interface SimuladorInterativoProps {
  params: SimulatorParams;
  onParamsChange: (params: SimulatorParams) => void;
}

export const SimuladorInterativo = ({ params, onParamsChange }: SimuladorInterativoProps) => {
  const { baseUsers, growthRate, arpu, timePeriod } = params;
  
  const projectedUsers = useMemo(() => {
    return Math.round(baseUsers * Math.pow(1 + growthRate / 100, timePeriod));
  }, [baseUsers, growthRate, timePeriod]);

  const projectedRevenue = useMemo(() => {
    return projectedUsers * arpu;
  }, [projectedUsers, arpu]);

  const handleParamChange = (key: keyof SimulatorParams, value: number) => {
    onParamsChange({ ...params, [key]: value });
  };

  return (
    <section id="simulador" className="mb-12" aria-labelledby="simulador-heading">
      <h2 id="simulador-heading" className="text-3xl font-bold mb-6">Simulador Interativo</h2>
      
      <div className="grid md:grid-cols-3 gap-6">
        <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="bg-primary/10 p-2 rounded-lg">
                <Users className="h-6 w-6 text-primary" />
              </div>
              Crescimento de Usuários
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label htmlFor="baseUsers" className="block text-sm font-medium mb-2">
                Usuários Iniciais (N₀)
              </label>
              <Slider
                id="baseUsers"
                min={50}
                max={500}
                step={10}
                value={[baseUsers]}
                onValueChange={(value) => handleParamChange('baseUsers', value[0])}
                className="mb-2"
                aria-label="Definir usuários iniciais"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>50</span>
                <span className="font-bold text-primary" aria-live="polite">{baseUsers}</span>
                <span>500</span>
              </div>
            </div>

            <div>
              <label htmlFor="growthRate" className="block text-sm font-medium mb-2">
                Taxa de Crescimento (r) %/mês
              </label>
              <Slider
                id="growthRate"
                min={1}
                max={30}
                step={0.5}
                value={[growthRate]}
                onValueChange={(value) => handleParamChange('growthRate', value[0])}
                className="mb-2"
                aria-label="Definir taxa de crescimento"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>1%</span>
                <span className="font-bold text-primary" aria-live="polite">{growthRate}%</span>
                <span>30%</span>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground mb-2">Projeção:</p>
              <p className="font-bold text-2xl text-primary" aria-live="polite">
                {projectedUsers.toLocaleString('pt-BR')} usuários
              </p>
              <p className="text-sm text-muted-foreground">em {timePeriod} meses</p>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="bg-success/10 p-2 rounded-lg">
                <DollarSign className="h-6 w-6 text-success" />
              </div>
              Projeção de Receita
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label htmlFor="arpu" className="block text-sm font-medium mb-2">
                ARPU (Receita por Usuário) R$
              </label>
              <Slider
                id="arpu"
                min={5}
                max={50}
                step={1}
                value={[arpu]}
                onValueChange={(value) => handleParamChange('arpu', value[0])}
                className="mb-2"
                aria-label="Definir receita por usuário"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>R$5</span>
                <span className="font-bold text-success" aria-live="polite">R${arpu}</span>
                <span>R$50</span>
              </div>
            </div>

            <div>
              <label htmlFor="timePeriod" className="block text-sm font-medium mb-2">
                Período de Projeção (meses)
              </label>
              <Slider
                id="timePeriod"
                min={3}
                max={36}
                step={1}
                value={[timePeriod]}
                onValueChange={(value) => handleParamChange('timePeriod', value[0])}
                className="mb-2"
                aria-label="Definir período de projeção"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>3</span>
                <span className="font-bold text-success" aria-live="polite">{timePeriod}</span>
                <span>36</span>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground mb-2">Receita total projetada:</p>
              <p className="font-bold text-2xl text-success" aria-live="polite">
                R$ {projectedRevenue.toLocaleString('pt-BR')}
              </p>
              <p className="text-sm text-muted-foreground">em {timePeriod} meses</p>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <div className="bg-destructive/10 p-2 rounded-lg">
                <TrendingUp className="h-6 w-6 text-destructive" />
              </div>
              Custos e ROI
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <p className="text-sm font-medium mb-3">Investimento Inicial:</p>
              <div className="bg-muted p-4 rounded-lg">
                <p className="font-bold text-xl text-primary">R$ 16.300,00</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Desenvolvimento e infraestrutura
                </p>
              </div>
            </div>

            <div>
              <p className="text-sm font-medium mb-3">Custos Mensais:</p>
              <div className="grid grid-cols-2 gap-2">
                <div className="bg-destructive/10 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground">Servidores</p>
                  <p className="font-bold text-destructive">R$350</p>
                </div>
                <div className="bg-destructive/10 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground">Licenças</p>
                  <p className="font-bold text-destructive">R$250</p>
                </div>
                <div className="bg-destructive/10 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground">Marketing</p>
                  <p className="font-bold text-destructive">R$150</p>
                </div>
                <div className="bg-destructive/10 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground">Suporte</p>
                  <p className="font-bold text-destructive">R$50</p>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-border">
              <p className="text-sm text-muted-foreground mb-2">Total Mensal:</p>
              <p className="font-bold text-2xl text-destructive">R$ 800,00</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
};
