import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Leaf, Zap, Server, Cloud } from "lucide-react";

export const Sustentabilidade = () => {
  return (
    <section id="sustentabilidade" className="mb-12" aria-labelledby="sustentabilidade-heading">
      <Card className="card-hover bg-card/50 backdrop-blur border-border/50">
        <CardHeader>
          <CardTitle id="sustentabilidade-heading" className="text-3xl flex items-center gap-3">
            <Leaf className="h-8 w-8 text-success" />
            Sustentabilidade e Eficiência
          </CardTitle>
          <CardDescription className="text-base">
            Compromisso com práticas sustentáveis e eficiência energética
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <Card className="bg-success/5 border-success/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Server className="h-6 w-6 text-success" />
                  Hardware Otimizado
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2 text-success">SSD vs HD</h4>
                  <p className="text-sm text-muted-foreground">
                    Uso de SSDs reduz consumo energético em até 70% e melhora performance em 300%
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-success">Memória DDR5</h4>
                  <p className="text-sm text-muted-foreground">
                    Eficiência energética 20% superior ao DDR4, consumindo apenas 1.1V
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-success">CPU Eficiente</h4>
                  <p className="text-sm text-muted-foreground">
                    Processadores modernos com TDP otimizado (65W vs 95W de gerações anteriores)
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-info/5 border-info/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Cloud className="h-6 w-6 text-info" />
                  Infraestrutura Cloud
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2 text-info">Escalabilidade Automática</h4>
                  <p className="text-sm text-muted-foreground">
                    Recursos alocados dinamicamente, reduzindo desperdício energético
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-info">Datacenters Verdes</h4>
                  <p className="text-sm text-muted-foreground">
                    Uso de energia renovável e refrigeração natural quando possível
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold mb-2 text-info">Otimização de Código</h4>
                  <p className="text-sm text-muted-foreground">
                    Algoritmos eficientes reduzem processamento necessário em até 40%
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="mt-6 bg-warning/5 border-warning/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Zap className="h-6 w-6 text-warning" />
                Métricas de Impacto Ambiental
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-background/50 rounded-lg">
                  <p className="text-3xl font-bold text-warning mb-2">-45%</p>
                  <p className="text-sm text-muted-foreground">Redução no consumo energético com otimizações</p>
                </div>
                <div className="text-center p-4 bg-background/50 rounded-lg">
                  <p className="text-3xl font-bold text-success mb-2">80%</p>
                  <p className="text-sm text-muted-foreground">Energia de fontes renováveis nos datacenters</p>
                </div>
                <div className="text-center p-4 bg-background/50 rounded-lg">
                  <p className="text-3xl font-bold text-info mb-2">100%</p>
                  <p className="text-sm text-muted-foreground">Compensação de carbono das operações</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </section>
  );
};
